"""
generar_datos.py
----------------
Fase 1 - Preparación de los datos.

Genera conjuntos de datos SINTÉTICOS de ventas para una empresa comercial que
opera en varias ciudades de Colombia. Los datos no contienen información
personal: solo transacciones con los campos exigidos por la guía.

Campos:
    id_venta         Identificador único de la transacción (V0000001, ...)
    fecha            Día de la venta (AAAA-MM-DD), año 2025
    ciudad           Ciudad donde se efectuó la venta
    producto         Nombre del producto
    categoria        Categoría del producto (campo adicional)
    cantidad         Unidades vendidas
    precio_unitario  Valor de cada unidad en pesos colombianos (entero)

Uso:
    python generar_datos.py                 # genera 10k, 100k, 500k y 1M
    python generar_datos.py 50000           # genera un único archivo de 50.000
"""

import csv
import os
import random
import sys
from datetime import date, timedelta

# Semilla fija: cualquier integrante del equipo obtiene exactamente los mismos datos.
SEMILLA = 2026

CARPETA_DATOS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "datos")

# Ciudades y peso relativo de ventas (las ciudades grandes venden más).
CIUDADES = {
    "Bogotá": 30, "Medellín": 18, "Cali": 13, "Barranquilla": 10,
    "Cartagena": 7, "Bucaramanga": 6, "Pereira": 4, "Manizales": 3,
    "Cúcuta": 3, "Santa Marta": 2, "Ibagué": 2, "Villavicencio": 2,
}

# Catálogo: producto -> (categoría, precio base en COP, popularidad relativa).
PRODUCTOS = {
    "Arroz 5 kg":            ("Alimentos", 18_900, 16),
    "Aceite 3 L":            ("Alimentos", 32_500, 12),
    "Café 500 g":            ("Alimentos", 21_400, 14),
    "Leche x6":              ("Alimentos", 22_800, 15),
    "Detergente 3 kg":       ("Aseo", 27_300, 10),
    "Papel higiénico x12":   ("Aseo", 24_600, 13),
    "Shampoo 750 ml":        ("Aseo", 19_900, 7),
    "Camiseta básica":       ("Ropa", 39_900, 6),
    "Jean clásico":          ("Ropa", 119_900, 4),
    "Tenis deportivos":      ("Ropa", 219_900, 3),
    "Audífonos Bluetooth":   ("Tecnología", 149_900, 4),
    "Celular gama media":    ("Tecnología", 1_099_000, 2),
    "Portátil 14\"":          ("Tecnología", 2_499_000, 1),
    "Memoria USB 64 GB":     ("Tecnología", 39_900, 5),
    "Licuadora":             ("Hogar", 189_900, 2),
    "Juego de ollas":        ("Hogar", 259_900, 2),
    "Sábanas dobles":        ("Hogar", 89_900, 3),
    "Cuaderno argollado":    ("Papelería", 12_900, 8),
    "Kit escolar":           ("Papelería", 54_900, 3),
    "Balón de fútbol":       ("Deportes", 79_900, 3),
}

# Estacionalidad mensual (factor de demanda): picos en diciembre, junio
# (primas de mitad de año) y enero/febrero (temporada escolar).
ESTACIONALIDAD = {1: 1.10, 2: 1.05, 3: 0.90, 4: 0.88, 5: 0.95, 6: 1.15,
                  7: 1.00, 8: 0.92, 9: 0.90, 10: 0.97, 11: 1.12, 12: 1.45}

ANIO = 2025
TAMANIOS_POR_DEFECTO = [10_000, 100_000, 500_000, 1_000_000]


def _dias_ponderados():
    """Lista de los 365 días del año con su peso según la estacionalidad."""
    inicio = date(ANIO, 1, 1)
    dias = [inicio + timedelta(days=i) for i in range(365)]
    pesos = [ESTACIONALIDAD[d.month] for d in dias]
    return dias, pesos


def generar(n_registros, ruta_salida, semilla=SEMILLA):
    """Escribe un CSV con n_registros ventas sintéticas."""
    rnd = random.Random(semilla)
    dias, pesos_dias = _dias_ponderados()
    ciudades, pesos_ciudades = list(CIUDADES), list(CIUDADES.values())
    productos = list(PRODUCTOS)
    pesos_productos = [PRODUCTOS[p][2] for p in productos]

    # Se generan en bloques para no ocupar demasiada memoria.
    bloque = 50_000
    with open(ruta_salida, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id_venta", "fecha", "ciudad", "producto", "categoria",
                    "cantidad", "precio_unitario"])
        generados = 0
        while generados < n_registros:
            k = min(bloque, n_registros - generados)
            fechas = rnd.choices(dias, weights=pesos_dias, k=k)
            ciuds = rnd.choices(ciudades, weights=pesos_ciudades, k=k)
            prods = rnd.choices(productos, weights=pesos_productos, k=k)
            filas = []
            for i in range(k):
                categoria, precio_base, _ = PRODUCTOS[prods[i]]
                # Variación de precio de +-8 % por promociones o región,
                # redondeada a centenas como en un ticket real.
                precio = round(precio_base * rnd.uniform(0.92, 1.08), -2)
                # Los productos baratos se compran en más unidades.
                maximo = 6 if precio_base < 60_000 else 2
                cantidad = rnd.randint(1, maximo)
                filas.append([f"V{generados + i + 1:07d}",
                              fechas[i].isoformat(), ciuds[i], prods[i],
                              categoria, cantidad, int(precio)])
            w.writerows(filas)
            generados += k
    return ruta_salida


def nombre_archivo(n):
    return os.path.join(CARPETA_DATOS, f"ventas_{n}.csv")


if __name__ == "__main__":
    os.makedirs(CARPETA_DATOS, exist_ok=True)
    tamanios = [int(a) for a in sys.argv[1:]] or TAMANIOS_POR_DEFECTO
    for n in tamanios:
        ruta = generar(n, nombre_archivo(n))
        mb = os.path.getsize(ruta) / 1_048_576
        print(f"Generado {ruta}  ({n:,} registros, {mb:.1f} MB)")
