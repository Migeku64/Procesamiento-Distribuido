"""
pruebas_rendimiento.py
----------------------
Fase 4 - Pruebas de rendimiento.

Para cada tamaño de conjunto de datos mide, en las MISMAS condiciones:
    * Ts : tiempo del procesamiento secuencial (1 proceso).
    * Tp : tiempo del procesamiento distribuido simulado con 2 y 4 nodos
           (incluye crear los procesos, repartir, procesar y consolidar).
    * Tiempo de particionamiento (se mide aparte, porque en un clúster real
      los datos ya estarían repartidos en el sistema de archivos distribuido).
Cada medición se repite REPETICIONES veces y se reporta la MEDIANA para
reducir el efecto de ruido del sistema operativo.

Calcula Aceleración = Ts / Tp y Eficiencia = Aceleración / nodos.
Además verifica que el resultado distribuido sea idéntico al secuencial.

Salida: resultados/tiempos.csv, resultados/entorno.json y la tabla en consola.
"""

import csv
import json
import os
import platform
import statistics
import time

import generar_datos as gd
from procesamiento import (CARPETA_RESULTADOS, ejecutar_distribuido,
                           ejecutar_secuencial, particionar, resultados_iguales)

TAMANIOS = [10_000, 100_000, 500_000, 1_000_000]
CONFIG_NODOS = [2, 4]
REPETICIONES = 5


def entorno():
    """Características del equipo, para documentar las condiciones de prueba."""
    info = {"sistema": f"{platform.system()} {platform.release()}",
            "python": platform.python_version(),
            "nucleos_logicos": os.cpu_count(),
            "procesador": platform.processor() or "desconocido"}
    try:
        with open("/proc/cpuinfo") as f:
            for linea in f:
                if linea.startswith("model name"):
                    info["procesador"] = linea.split(":", 1)[1].strip()
                    break
        with open("/proc/meminfo") as f:
            kb = int(f.readline().split()[1])
            info["memoria_gb"] = round(kb / 1_048_576, 1)
    except OSError:
        pass
    return info


def mediana_de(funcion):
    tiempos, resultado = [], None
    for _ in range(REPETICIONES):
        resultado, t = funcion()
        tiempos.append(t)
    return statistics.median(tiempos), resultado


def main():
    os.makedirs(CARPETA_RESULTADOS, exist_ok=True)
    info = entorno()
    with open(os.path.join(CARPETA_RESULTADOS, "entorno.json"), "w", encoding="utf-8") as f:
        json.dump(info, f, ensure_ascii=False, indent=2)
    print("Entorno de prueba:", info)

    filas = []
    for n in TAMANIOS:
        ruta = gd.nombre_archivo(n)
        if not os.path.exists(ruta):
            gd.generar(n, ruta)
        # Calentamiento: carga el archivo en la caché del sistema operativo
        # para que la primera medición no quede en desventaja.
        ejecutar_secuencial(ruta)

        ts, rep_seq = mediana_de(lambda: ejecutar_secuencial(ruta))
        filas.append({"registros": n, "modo": "Secuencial", "nodos": 1,
                      "t_particionado_s": 0.0, "t_procesamiento_s": round(ts, 4),
                      "aceleracion": 1.0, "eficiencia": 1.0, "resultado_correcto": True})
        print(f"\n{n:>9,} registros | Secuencial           Ts = {ts:.4f} s")

        for nodos in CONFIG_NODOS:
            t0 = time.perf_counter()
            rutas = particionar(ruta, nodos)
            t_part = time.perf_counter() - t0
            tp, rep_dis = mediana_de(lambda: ejecutar_distribuido(rutas, nodos))
            ok = resultados_iguales(rep_seq, rep_dis)
            acel = ts / tp
            filas.append({"registros": n, "modo": "Distribuido simulado", "nodos": nodos,
                          "t_particionado_s": round(t_part, 4), "t_procesamiento_s": round(tp, 4),
                          "aceleracion": round(acel, 2), "eficiencia": round(acel / nodos, 2),
                          "resultado_correcto": ok})
            print(f"{n:>9,} registros | Distribuido {nodos} nodos  Tp = {tp:.4f} s "
                  f"| partición {t_part:.4f} s | S = {acel:.2f} | E = {acel / nodos:.2f} | correcto = {ok}")

    ruta_csv = os.path.join(CARPETA_RESULTADOS, "tiempos.csv")
    with open(ruta_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(filas[0]))
        w.writeheader()
        w.writerows(filas)
    print("\nTabla guardada en", ruta_csv)


if __name__ == "__main__":
    main()
