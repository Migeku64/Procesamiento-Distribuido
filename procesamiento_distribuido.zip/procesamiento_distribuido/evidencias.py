"""
evidencias.py
-------------
Convierte las salidas de consola guardadas en resultados/salida_*.txt en
imágenes tipo terminal para incluirlas como evidencia en el informe.
"""

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.dirname(os.path.abspath(__file__))
RES, FIG = os.path.join(BASE, "resultados"), os.path.join(BASE, "figuras")


def terminal(comando, lineas, nombre, ancho_pulg=7.5):
    texto = [f"$ {comando}"] + lineas
    alto = 0.17 * len(texto) + 0.35
    fig = plt.figure(figsize=(ancho_pulg, alto))
    fig.patch.set_facecolor("#1e1e1e")
    for i, linea in enumerate(texto):
        color = "#9cdcfe" if i == 0 else ("#f48771" if "FALLO" in linea or "PERDIDA" in linea
                                          else "#b5cea8" if "True" in linea or "[OK]" in linea
                                          else "#d4d4d4")
        fig.text(0.015, 1 - (i + 1) * 0.17 / alto, linea, family="DejaVu Sans Mono",
                 fontsize=7.2, color=color, va="top", parse_math=False)
    fig.savefig(os.path.join(FIG, nombre), dpi=200, facecolor=fig.get_facecolor())
    plt.close(fig)


def leer(nombre):
    import textwrap
    salida = []
    with open(os.path.join(RES, nombre), encoding="utf-8") as f:
        for l in f:
            l = l.rstrip("\n").replace(BASE + os.sep, "")
            salida += textwrap.wrap(l, 118, subsequent_indent="    ") if len(l) > 118 else [l]
    return salida


# 1. Pruebas de rendimiento (completo)
terminal("python pruebas_rendimiento.py",
         [l for l in leer("salida_pruebas_rendimiento.txt")], "evidencia_rendimiento.png", 9.2)

# 2. Tolerancia a fallos (completo)
terminal("python tolerancia_fallos.py datos/ventas_500000.csv",
         leer("salida_tolerancia_fallos.txt"), "evidencia_tolerancia.png", 8.4)

# 3. Ejecución con 1.000.000 de registros: secuencial resumido + bitácora
#    de nodos + verificación (se omiten las tablas repetidas).
lin = leer("salida_procesamiento_1M.txt")
ini_dis = next(i for i, l in enumerate(lin) if l.startswith("Particionamiento"))
fin_ciud = next(i for i, l in enumerate(lin) if l.startswith("Top 5"))
seleccion = (lin[:fin_ciud] + ["  ... (top 5 e ingresos por mes omitidos) ..."] +
             lin[ini_dis:ini_dis + 5] + ["  ... (tablas idénticas a las del modo secuencial) ..."] +
             [l for l in lin if l.startswith("Verificación") or l.startswith("Aceleración")])
terminal("python procesamiento.py datos/ventas_1000000.csv --nodos 2",
         seleccion, "evidencia_procesamiento_1M.png", 7.5)
print("Evidencias generadas en", FIG)
