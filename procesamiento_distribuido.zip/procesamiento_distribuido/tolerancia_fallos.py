"""
tolerancia_fallos.py
--------------------
Fase 5, pregunta 4 - ¿Qué sucede si uno de los procesos falla antes de
entregar sus resultados?

Se simula la caída del nodo que procesa la partición 2 (de 4) en dos
escenarios:

    A. SIN tolerancia a fallos (0 reintentos): la partición se pierde y el
       coordinador consolida un reporte INCOMPLETO (faltan ventas).
    B. CON tolerancia a fallos (re-ejecución): el coordinador detecta el fallo
       y reasigna la partición; el reporte final es idéntico al secuencial.

Uso:
    python tolerancia_fallos.py datos/ventas_500000.csv
"""

import sys

from procesamiento import (cop, ejecutar_distribuido, ejecutar_secuencial,
                           particionar, resultados_iguales)

NODOS = 4
PARTICION_QUE_FALLA = 2


def main(ruta):
    rep_seq, t_seq = ejecutar_secuencial(ruta)
    rutas = particionar(ruta, NODOS)
    print(f"Referencia secuencial: {rep_seq['registros']:,} registros, "
          f"ingresos {cop(rep_seq['ingresos_totales'])} ({t_seq:.3f} s)")

    for titulo, reintentos in [("A. SIN tolerancia a fallos", 0),
                               ("B. CON tolerancia a fallos (re-ejecución)", 2)]:
        bitacora = []
        rep, t = ejecutar_distribuido(rutas, NODOS,
                                      particiones_que_fallan=(PARTICION_QUE_FALLA,),
                                      max_reintentos=reintentos, bitacora=bitacora)
        print(f"\n=== {titulo} ===")
        print("\n".join(bitacora))
        faltan = rep_seq["registros"] - rep["registros"]
        dif = rep_seq["ingresos_totales"] - rep["ingresos_totales"]
        print(f"Registros consolidados: {rep['registros']:,}  (faltan {faltan:,})")
        print(f"Ingresos consolidados:  {cop(rep['ingresos_totales'])}  (diferencia {cop(dif)})")
        print(f"Top 5 igual al secuencial: {rep['top5_productos_unidades'] == rep_seq['top5_productos_unidades']}")
        print(f"Resultado idéntico al secuencial: {resultados_iguales(rep_seq, rep)}  | tiempo {t:.3f} s")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "datos/ventas_500000.csv")
