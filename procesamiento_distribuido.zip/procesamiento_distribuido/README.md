# Guía 8 – Procesamiento distribuido de datos

Análisis distribuido (simulado con procesos independientes) de las ventas de una empresa comercial en Colombia.

## Estructura
- `generar_datos.py` – Fase 1: genera los CSV sintéticos (semilla fija 2026).
- `procesamiento.py` – Fase 3: particionamiento, nodos (Map), coordinador con re-ejecución y consolidación (Reduce).
- `pruebas_rendimiento.py` – Fase 4: tiempos, aceleración y eficiencia → `resultados/tiempos.csv`.
- `tolerancia_fallos.py` – Fase 5: simulación de la caída de un nodo.
- `graficas.py`, `evidencias.py`, `arquitectura.dot` – figuras del informe.
- `datos/` – conjuntos de datos (10k, 100k, 500k y 1M registros).
- `resultados/` – reportes JSON, tiempos y salidas de consola.
- `figuras/` – diagrama, gráficas y evidencias.

## Ejecución
```
python generar_datos.py
python procesamiento.py datos/ventas_100000.csv --nodos 2
python pruebas_rendimiento.py
python tolerancia_fallos.py datos/ventas_500000.csv
python graficas.py && python evidencias.py
dot -Tpng -Gdpi=200 arquitectura.dot -o figuras/arquitectura.png
```
Requisitos: Python 3.10+ (solo biblioteca estándar para el procesamiento); matplotlib para las gráficas; Graphviz para el diagrama.

Nota: es una simulación de un clúster en un solo equipo, no un clúster distribuido real.
