"""
graficas.py
-----------
Genera las figuras del informe a partir de los archivos de resultados:
    figuras/tiempos.png          tiempo de ejecución vs. tamaño del conjunto
    figuras/aceleracion.png      aceleración (Ts/Tp) por tamaño y nodos
    figuras/ingresos_ciudad.png  ingresos por ciudad (1.000.000 registros)
    figuras/ingresos_mes.png     ingresos por mes (1.000.000 registros)
    figuras/top5_productos.png   top 5 productos por unidades
"""

import csv
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

BASE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(BASE, "resultados")
FIG = os.path.join(BASE, "figuras")
os.makedirs(FIG, exist_ok=True)

# Paleta categórica validada (orden fijo) y tintas de texto.
AZUL, NARANJA, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
TEXTO, TEXTO2, GRILLA = "#0b0b0b", "#52514e", "#e4e3df"
MESES = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": GRILLA,
    "axes.labelcolor": TEXTO2, "xtick.color": TEXTO2, "ytick.color": TEXTO2,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRILLA, "grid.linewidth": 0.8,
    "axes.axisbelow": True, "figure.dpi": 200,
})


def miles_millones(x, _=None):
    return f"{x / 1e9:,.1f}".replace(".", ",")


def guardar(fig, nombre):
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, nombre), bbox_inches="tight", facecolor="white")
    plt.close(fig)


# --- Tiempos ---------------------------------------------------------------
with open(os.path.join(RES, "tiempos.csv"), encoding="utf-8") as f:
    filas = list(csv.DictReader(f))
tamanios = sorted({int(r["registros"]) for r in filas})
etiquetas = [f"{n:,}".replace(",", ".") for n in tamanios]


def serie(nodos, campo):
    return [float(next(r[campo] for r in filas if int(r["registros"]) == n and int(r["nodos"]) == nodos))
            for n in tamanios]


fig, ax = plt.subplots(figsize=(6.5, 3.6))
x = range(len(tamanios))
ancho = 0.26
for i, (nodos, color, nombre) in enumerate([(1, AZUL, "Secuencial (1 proceso)"),
                                            (2, NARANJA, "Distribuido simulado, 2 nodos"),
                                            (4, AQUA, "Distribuido simulado, 4 nodos")]):
    valores = serie(nodos, "t_procesamiento_s")
    barras = ax.bar([xi + (i - 1) * (ancho + 0.02) for xi in x], valores, ancho,
                    color=color, label=nombre, edgecolor="white", linewidth=1)
    for b, v in zip(barras, valores):
        ax.text(b.get_x() + b.get_width() / 2, v, f"{v:.2f}".replace(".", ","),
                ha="center", va="bottom", fontsize=7, color=TEXTO2)
ax.set_xticks(list(x), etiquetas)
ax.set_xlabel("Registros procesados")
ax.set_ylabel("Tiempo (segundos, mediana de 5)")
ax.legend(frameon=False, fontsize=8, loc="upper left")
ax.grid(axis="x", visible=False)
guardar(fig, "tiempos.png")

# --- Aceleración -----------------------------------------------------------
fig, ax = plt.subplots(figsize=(6.5, 3.4))
for i, (nodos, color) in enumerate([(2, NARANJA), (4, AQUA)]):
    valores = serie(nodos, "aceleracion")
    barras = ax.bar([xi + (i - 0.5) * 0.36 for xi in x], valores, 0.34, color=color,
                    label=f"{nodos} nodos", edgecolor="white", linewidth=1)
    for b, v in zip(barras, valores):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.03, f"{v:.2f}".replace(".", ","),
                ha="center", va="bottom", fontsize=8, color=TEXTO)
ax.axhline(1, color=TEXTO2, linewidth=1, linestyle="--", label="Sin mejora (S = 1)")
ax.axhline(2, color=TEXTO2, linewidth=1, linestyle=":", label="Máximo teórico con 2 núcleos (S = 2)")
ax.set_ylim(0, 2.9)
ax.set_xticks(list(x), etiquetas)
ax.set_xlabel("Registros procesados")
ax.set_ylabel("Aceleración  S = Ts / Tp")
ax.legend(frameon=False, fontsize=8, loc="upper left", ncol=2)
ax.grid(axis="x", visible=False)
guardar(fig, "aceleracion.png")

# --- Resultados de negocio (1.000.000 registros) ---------------------------
with open(os.path.join(RES, "reporte_ventas_1000000_distribuido.json"), encoding="utf-8") as f:
    rep = json.load(f)

ciudades = list(rep["ingresos_por_ciudad"])[::-1]
valores = [rep["ingresos_por_ciudad"][c] for c in ciudades]
fig, ax = plt.subplots(figsize=(6.5, 3.8))
ax.barh(ciudades, valores, color=AZUL, height=0.7)
for c, v in zip(ciudades, valores):
    ax.text(v, c, f"  {miles_millones(v)}", va="center", fontsize=7.5, color=TEXTO2)
ax.xaxis.set_major_formatter(FuncFormatter(miles_millones))
ax.set_xlabel("Ingresos (miles de millones de pesos)")
ax.grid(axis="y", visible=False)
ax.set_xlim(0, max(valores) * 1.15)
guardar(fig, "ingresos_ciudad.png")

meses = list(rep["ingresos_por_mes"])
valores = [rep["ingresos_por_mes"][m] for m in meses]
fig, ax = plt.subplots(figsize=(6.5, 3.2))
barras = ax.bar([MESES[int(m[5:]) - 1] for m in meses], valores, color=AZUL, width=0.7)
for b, v in zip(barras, valores):
    ax.text(b.get_x() + b.get_width() / 2, v, miles_millones(v), ha="center",
            va="bottom", fontsize=7, color=TEXTO2)
ax.yaxis.set_major_formatter(FuncFormatter(miles_millones))
ax.set_ylabel("Ingresos (miles de millones)")
ax.grid(axis="x", visible=False)
guardar(fig, "ingresos_mes.png")

productos = list(rep["top5_productos_unidades"])[::-1]
valores = [rep["top5_productos_unidades"][p] for p in productos]
fig, ax = plt.subplots(figsize=(6.5, 2.4))
ax.barh(productos, valores, color=AZUL, height=0.65)
for p, v in zip(productos, valores):
    ax.text(v, p, "  " + f"{v:,}".replace(",", "."), va="center", fontsize=8, color=TEXTO2)
ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:,.0f}".replace(",", ".")))
ax.set_xlabel("Unidades vendidas")
ax.set_xlim(0, max(valores) * 1.18)
ax.grid(axis="y", visible=False)
guardar(fig, "top5_productos.png")

print("Figuras generadas en", FIG)
