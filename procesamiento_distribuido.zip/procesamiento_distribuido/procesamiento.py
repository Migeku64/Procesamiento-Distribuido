"""
procesamiento.py
----------------
Fase 3 - Implementación del procesamiento.

Implementa el análisis de ventas de dos maneras:

1. SECUENCIAL: un único proceso lee todo el CSV y calcula los indicadores.
2. DISTRIBUIDO (SIMULADO): un proceso coordinador divide el CSV en particiones
   (como los bloques de HDFS), las reparte entre varios procesos trabajadores
   independientes (los "nodos"), cada uno calcula resultados PARCIALES y el
   coordinador los CONSOLIDA en el resultado final (patrón Map/Reduce).

IMPORTANTE: los "nodos" son procesos del sistema operativo que corren en el
mismo equipo (módulo multiprocessing). Es una SIMULACIÓN de un clúster: no hay
red de por medio, por lo que los costos de comunicación son menores que en un
clúster real, pero el modelo de programación (particionar -> procesar ->
consolidar) es el mismo que usan Hadoop MapReduce y Apache Spark.

Indicadores calculados:
    * Ingresos totales por ciudad.
    * Top 5 de productos por unidades vendidas.
    * Ingresos totales por mes.

Uso:
    python procesamiento.py datos/ventas_100000.csv --nodos 2
"""

import argparse
import csv
import json
import os
import time
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed

CARPETA_BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA_PARTICIONES = os.path.join(CARPETA_BASE, "particiones")
CARPETA_RESULTADOS = os.path.join(CARPETA_BASE, "resultados")

MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
         "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]


# ---------------------------------------------------------------------------
# 1. Lógica de negocio (la misma para el modo secuencial y el distribuido)
# ---------------------------------------------------------------------------
def procesar_filas(lector):
    """Recorre las filas de un CSV y devuelve los acumulados PARCIALES.

    Se usan Counter (diccionarios que suman) porque los resultados parciales
    de distintos nodos se pueden combinar simplemente sumándolos: las tres
    operaciones son asociativas y conmutativas, requisito clave para que la
    consolidación sea correcta sin importar el orden en que lleguen.
    Los valores monetarios son enteros (pesos), así la suma es exacta.
    """
    ingresos_ciudad = Counter()
    unidades_producto = Counter()
    ingresos_mes = Counter()
    registros = 0
    for fila in lector:
        cantidad = int(fila["cantidad"])
        ingreso = cantidad * int(fila["precio_unitario"])
        ingresos_ciudad[fila["ciudad"]] += ingreso
        unidades_producto[fila["producto"]] += cantidad
        ingresos_mes[fila["fecha"][:7]] += ingreso      # clave "AAAA-MM"
        registros += 1
    return {"registros": registros,
            "ingresos_ciudad": ingresos_ciudad,
            "unidades_producto": unidades_producto,
            "ingresos_mes": ingresos_mes}


def procesar_archivo(ruta):
    """Abre un CSV (completo o partición) y lo procesa."""
    with open(ruta, newline="", encoding="utf-8") as f:
        return procesar_filas(csv.DictReader(f))


# ---------------------------------------------------------------------------
# 2. Particionamiento (mecanismo de distribución)
# ---------------------------------------------------------------------------
def particionar(ruta_csv, n_particiones, carpeta=CARPETA_PARTICIONES):
    """Divide el CSV en n_particiones archivos de tamaño similar.

    Estrategia: particionamiento por RANGOS CONTIGUOS de registros (igual que
    HDFS divide un archivo en bloques). Cada partición conserva el encabezado
    para poder procesarse de forma independiente en cualquier nodo.
    """
    os.makedirs(carpeta, exist_ok=True)
    with open(ruta_csv, encoding="utf-8") as f:
        encabezado = f.readline()
        lineas = f.readlines()
    base = os.path.splitext(os.path.basename(ruta_csv))[0]
    tam = -(-len(lineas) // n_particiones)          # división redondeada hacia arriba
    rutas = []
    for i in range(n_particiones):
        ruta = os.path.join(carpeta, f"{base}_part{i + 1:02d}.csv")
        with open(ruta, "w", encoding="utf-8") as out:
            out.write(encabezado)
            out.writelines(lineas[i * tam:(i + 1) * tam])
        rutas.append(ruta)
    return rutas


# ---------------------------------------------------------------------------
# 3. Nodo trabajador (lo que ejecutaría cada máquina del clúster)
# ---------------------------------------------------------------------------
def tarea_nodo(id_particion, ruta, intento=1, particiones_que_fallan=()):
    """Tarea que ejecuta cada nodo sobre UNA partición.

    `particiones_que_fallan` permite simular la caída de un nodo (Fase 5,
    pregunta 4): si la partición está en esa lista y es el primer intento,
    el nodo "se cae" lanzando una excepción antes de entregar su resultado.
    """
    if id_particion in particiones_que_fallan and intento == 1:
        raise RuntimeError(f"Nodo que procesaba la partición {id_particion} "
                           f"dejó de responder (fallo simulado)")
    inicio = time.perf_counter()
    parcial = procesar_archivo(ruta)
    parcial["id_particion"] = id_particion
    parcial["pid"] = os.getpid()                     # proceso que lo ejecutó
    parcial["segundos"] = time.perf_counter() - inicio
    return parcial


# ---------------------------------------------------------------------------
# 4. Consolidación (fase Reduce)
# ---------------------------------------------------------------------------
def consolidar(parciales):
    """Suma los resultados parciales y calcula los indicadores finales."""
    total = {"registros": 0, "ingresos_ciudad": Counter(),
             "unidades_producto": Counter(), "ingresos_mes": Counter()}
    for p in parciales:
        total["registros"] += p["registros"]
        total["ingresos_ciudad"].update(p["ingresos_ciudad"])
        total["unidades_producto"].update(p["unidades_producto"])
        total["ingresos_mes"].update(p["ingresos_mes"])
    return reporte_final(total)


def reporte_final(acum):
    """Convierte los acumulados en el reporte con los tres indicadores."""
    return {
        "registros": acum["registros"],
        "ingresos_por_ciudad": dict(acum["ingresos_ciudad"].most_common()),
        "top5_productos_unidades": dict(acum["unidades_producto"].most_common(5)),
        "ingresos_por_mes": dict(sorted(acum["ingresos_mes"].items())),
        "ingresos_totales": sum(acum["ingresos_ciudad"].values()),
    }


# ---------------------------------------------------------------------------
# 5. Modos de ejecución
# ---------------------------------------------------------------------------
def ejecutar_secuencial(ruta_csv):
    """Procesamiento centralizado: un solo proceso, todo el archivo."""
    inicio = time.perf_counter()
    reporte = reporte_final(procesar_archivo(ruta_csv))
    return reporte, time.perf_counter() - inicio


def ejecutar_distribuido(rutas_particiones, n_nodos, particiones_que_fallan=(),
                         max_reintentos=2, bitacora=None):
    """Coordinador: reparte particiones a n_nodos procesos y consolida.

    Tolerancia a fallos: si un nodo falla, la partición se vuelve a asignar
    (re-ejecución de la tarea, como hacen Hadoop y Spark) hasta max_reintentos.
    Si max_reintentos = 0 la partición se pierde y el resultado queda
    INCOMPLETO, lo que permite mostrar el efecto de no tener tolerancia.
    """
    log = bitacora if bitacora is not None else []
    inicio = time.perf_counter()
    parciales, perdidas = [], []
    with ProcessPoolExecutor(max_workers=n_nodos) as pool:
        pendientes = {pool.submit(tarea_nodo, i + 1, r, 1, particiones_que_fallan): (i + 1, r, 1)
                      for i, r in enumerate(rutas_particiones)}
        while pendientes:
            for fut in as_completed(list(pendientes)):
                id_p, ruta, intento = pendientes.pop(fut)
                try:
                    p = fut.result()
                    parciales.append(p)
                    log.append(f"[OK]    partición {id_p} procesada por PID {p['pid']} "
                               f"({p['registros']:,} registros, {p['segundos']:.3f} s, intento {intento})")
                except RuntimeError as e:
                    log.append(f"[FALLO] {e}")
                    if intento <= max_reintentos:
                        log.append(f"[REINT] reasignando partición {id_p} a otro nodo (intento {intento + 1})")
                        nuevo = pool.submit(tarea_nodo, id_p, ruta, intento + 1, particiones_que_fallan)
                        pendientes[nuevo] = (id_p, ruta, intento + 1)
                    else:
                        perdidas.append(id_p)
                        log.append(f"[PERDIDA] partición {id_p} sin resultado: el reporte quedará incompleto")
                break   # volver a construir la lista de pendientes
    reporte = consolidar(parciales)
    reporte["particiones_perdidas"] = perdidas
    reporte["detalle_particiones"] = sorted(
        [{"particion": p["id_particion"], "pid": p["pid"], "registros": p["registros"],
          "segundos": round(p["segundos"], 4)} for p in parciales],
        key=lambda d: d["particion"])
    return reporte, time.perf_counter() - inicio


def resultados_iguales(a, b):
    """Verifica que dos reportes tengan exactamente los mismos indicadores."""
    claves = ["registros", "ingresos_por_ciudad", "top5_productos_unidades",
              "ingresos_por_mes", "ingresos_totales"]
    return all(a[k] == b[k] for k in claves)


# ---------------------------------------------------------------------------
# 6. Presentación de resultados
# ---------------------------------------------------------------------------
def cop(valor):
    """Formato de moneda colombiana: $ 1.234.567"""
    return "$ " + f"{valor:,.0f}".replace(",", ".")


def imprimir_reporte(rep, titulo):
    print(f"\n=== {titulo} ===")
    print(f"Registros procesados: {rep['registros']:,}".replace(",", "."))
    print(f"Ingresos totales:     {cop(rep['ingresos_totales'])}")
    print("\nIngresos por ciudad:")
    for c, v in rep["ingresos_por_ciudad"].items():
        print(f"  {c:<15}{cop(v):>22}")
    print("\nTop 5 productos por unidades vendidas:")
    for i, (p, u) in enumerate(rep["top5_productos_unidades"].items(), 1):
        print(f"  {i}. {p:<22}{u:>12,} u".replace(",", "."))
    print("\nIngresos por mes:")
    for m, v in rep["ingresos_por_mes"].items():
        print(f"  {MESES[int(m[5:]) - 1]:<12}{cop(v):>22}")


def guardar_reporte(rep, nombre):
    os.makedirs(CARPETA_RESULTADOS, exist_ok=True)
    ruta = os.path.join(CARPETA_RESULTADOS, nombre)
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(rep, f, ensure_ascii=False, indent=2)
    return ruta


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Análisis distribuido de ventas")
    ap.add_argument("archivo", help="CSV de ventas")
    ap.add_argument("--nodos", type=int, default=2, help="procesos trabajadores")
    ap.add_argument("--particiones", type=int, default=None,
                    help="número de particiones (por defecto = nodos)")
    args = ap.parse_args()
    n_part = args.particiones or args.nodos

    rep_seq, t_seq = ejecutar_secuencial(args.archivo)
    imprimir_reporte(rep_seq, f"SECUENCIAL ({t_seq:.3f} s)")

    t0 = time.perf_counter()
    rutas = particionar(args.archivo, n_part)
    t_part = time.perf_counter() - t0
    bitacora = []
    rep_dis, t_dis = ejecutar_distribuido(rutas, args.nodos, bitacora=bitacora)
    print(f"\nParticionamiento: {n_part} particiones en {t_part:.3f} s")
    print("\n".join(bitacora))
    imprimir_reporte(rep_dis, f"DISTRIBUIDO SIMULADO - {args.nodos} nodos ({t_dis:.3f} s)")

    print("\nVerificación: resultados idénticos =", resultados_iguales(rep_seq, rep_dis))
    print(f"Aceleración (Ts/Tp) = {t_seq / t_dis:.2f}")
    base = os.path.splitext(os.path.basename(args.archivo))[0]
    print("Reportes guardados en:",
          guardar_reporte(rep_seq, f"reporte_{base}_secuencial.json"), "y",
          guardar_reporte(rep_dis, f"reporte_{base}_distribuido.json"))
